from django.shortcuts import render
#from django utils import timezone
#from .models import Post
#from django.shortcuts import render, get_object_or_404
#from .forms import Postform
#from django.shortcuts import redirect

#def post_list(request):
		#posts = Post.objects .filter(published_date_Ite=timezone.now()).order_by('published_date')
		#return render(request,'blog/post_list.html'),{'posts':posts})
# Create your views here.
def post_list(request):
	return render(request,'blog/post_list.html',{})
 
